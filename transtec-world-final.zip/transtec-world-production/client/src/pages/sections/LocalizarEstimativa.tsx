import React, { useState } from 'react';
import { Search, Plus, Download } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';

export default function LocalizarEstimativaPage() {
  const { generatePDF } = usePDFGenerator();
  const [armadores, setArmadores] = useState([
    { id: 1, codigo: 'HLBU 9005234', data: '2025-04-16', turno: 'Dia', classificacao: 'CF', observacao: 'Lavador 1' },
    { id: 2, codigo: 'HLBU 9005235', data: '2025-04-16', turno: 'Noite', classificacao: 'CG', observacao: 'Lavador 2' },
    { id: 3, codigo: 'HLBU 9005236', data: '2025-04-15', turno: 'Dia', classificacao: 'CF', observacao: 'Oficina' },
  ]);

  const [formData, setFormData] = useState({
    armador: '',
    data: '',
    turno: '',
    classificacao: '',
    observacao: '',
  });

  const [busca, setBusca] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Controle registrado:', formData);
    setFormData({
      armador: '',
      data: '',
      turno: '',
      classificacao: '',
      observacao: '',
    });
  };

  const armadoresFiltrados = armadores.filter(a =>
    a.codigo.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Localizar Estimativa</h2>
        <button
          onClick={() => generatePDF('estimativa-content', 'estimativa', 'Relatório de Estimativas - TRANSTEC WORLD')}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Gerar PDF
        </button>
      </div>

      <div id="estimativa-content" className="space-y-6">

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <form onSubmit={handleSubmit} className="space-y-4">
          <h3 className="text-lg font-bold text-white mb-4">Registrar Controle</h3>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Armador</label>
            <input
              type="text"
              name="armador"
              value={formData.armador}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Ex: HLBU 9005234"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Data</label>
              <input
                type="date"
                name="data"
                value={formData.data}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Turno</label>
              <select
                name="turno"
                value={formData.turno}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              >
                <option value="">Selecionar...</option>
                <option value="Dia">Dia</option>
                <option value="Noite">Noite</option>
                <option value="Madrugada">Madrugada</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Classificação da Carga</label>
            <select
              name="classificacao"
              value={formData.classificacao}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            >
              <option value="">Selecionar...</option>
              <option value="CF">CF - Alimento</option>
              <option value="CG">CG - Carga Geral</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Observação</label>
            <select
              name="observacao"
              value={formData.observacao}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Selecionar...</option>
              <option value="Lavador 1">Lavador 1</option>
              <option value="Lavador 2">Lavador 2</option>
              <option value="Oficina">Oficina</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Registrar Controle
          </button>
        </form>
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4">Buscar Armador</h3>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="w-full bg-slate-600 text-white pl-10 pr-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="Buscar por código do armador..."
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-gray-300">
            <thead>
              <tr className="border-b border-slate-600">
                <th className="pb-3 font-semibold text-white">Armador</th>
                <th className="pb-3 font-semibold text-white">Data</th>
                <th className="pb-3 font-semibold text-white">Turno</th>
                <th className="pb-3 font-semibold text-white">Classificação</th>
                <th className="pb-3 font-semibold text-white">Observação</th>
                <th className="pb-3 font-semibold text-white">Ações</th>
              </tr>
            </thead>
            <tbody>
              {armadoresFiltrados.map((arm) => (
                <tr key={arm.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                  <td className="py-3 font-semibold text-white">{arm.codigo}</td>
                  <td className="py-3">{arm.data}</td>
                  <td className="py-3">{arm.turno}</td>
                  <td className="py-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold text-white ${
                      arm.classificacao === 'CF' ? 'bg-blue-600' : 'bg-purple-600'
                    }`}>
                      {arm.classificacao}
                    </span>
                  </td>
                  <td className="py-3">{arm.observacao || '-'}</td>
                  <td className="py-3">
                    <button className="text-indigo-400 hover:text-indigo-300 font-semibold text-sm">Ver</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-indigo-700 to-indigo-800 p-6 rounded-xl border border-indigo-600">
          <p className="text-indigo-200 text-sm">Total de Armadores</p>
          <p className="text-3xl font-bold text-white mt-2">{armadores.length}</p>
        </div>
        <div className="bg-gradient-to-br from-blue-700 to-blue-800 p-6 rounded-xl border border-blue-600">
          <p className="text-blue-200 text-sm">Classificação CF</p>
          <p className="text-3xl font-bold text-white mt-2">{armadores.filter(a => a.classificacao === 'CF').length}</p>
        </div>
        <div className="bg-gradient-to-br from-purple-700 to-purple-800 p-6 rounded-xl border border-purple-600">
          <p className="text-purple-200 text-sm">Classificação CG</p>
          <p className="text-3xl font-bold text-white mt-2">{armadores.filter(a => a.classificacao === 'CG').length}</p>
        </div>
      </div>
      </div>
    </div>
  );
}
