import React, { useState } from 'react';
import { Package, Plus, Eye, Download } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';

export default function InventarioPage() {
  const { generatePDF } = usePDFGenerator();
  const [tipoInventario, setTipoInventario] = useState('produtos');

  const inventarios = {
    produtos: [
      { id: 1, nome: 'Parafuso M8', quantidade: 500, minimo: 100, status: 'OK' },
      { id: 2, nome: 'Porca M8', quantidade: 45, minimo: 100, status: 'Crítico' },
      { id: 3, nome: 'Arruela M8', quantidade: 250, minimo: 100, status: 'OK' },
    ],
    tintas: [
      { id: 1, nome: 'Tinta Vermelha', quantidade: 20, minimo: 5, status: 'OK' },
      { id: 2, nome: 'Tinta Azul', quantidade: 3, minimo: 5, status: 'Crítico' },
      { id: 3, nome: 'Tinta Branca', quantidade: 15, minimo: 5, status: 'OK' },
    ],
    ferramentas: [
      { id: 1, nome: 'Chave Inglesa 10"', quantidade: 5, minimo: 2, status: 'OK' },
      { id: 2, nome: 'Furadeira Elétrica', quantidade: 1, minimo: 1, status: 'Crítico' },
      { id: 3, nome: 'Jogo de Chaves', quantidade: 3, minimo: 1, status: 'OK' },
    ],
    escritorio: [
      { id: 1, nome: 'Papel A4', quantidade: 10, minimo: 5, status: 'OK' },
      { id: 2, nome: 'Caneta Azul', quantidade: 2, minimo: 10, status: 'Crítico' },
      { id: 3, nome: 'Grampeador', quantidade: 4, minimo: 2, status: 'OK' },
    ],
    danificados: [
      { id: 1, nome: 'Parafuso Danificado', quantidade: 15, motivo: 'Oxidação' },
      { id: 2, nome: 'Porca Trincada', quantidade: 8, motivo: 'Impacto' },
      { id: 3, nome: 'Arruela Deformada', quantidade: 12, motivo: 'Deformação' },
    ],
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'OK': return 'bg-green-600';
      case 'Crítico': return 'bg-red-600';
      default: return 'bg-slate-600';
    }
  };

  const renderInventario = () => {
    const dados = inventarios[tipoInventario as keyof typeof inventarios];
    
    if (tipoInventario === 'danificados') {
      return (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-gray-300">
            <thead>
              <tr className="border-b border-slate-600">
                <th className="pb-3 font-semibold text-white">Produto</th>
                <th className="pb-3 font-semibold text-white">Quantidade</th>
                <th className="pb-3 font-semibold text-white">Motivo</th>
                <th className="pb-3 font-semibold text-white">Ações</th>
              </tr>
            </thead>
            <tbody>
              {dados.map((item: any) => (
                <tr key={item.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                  <td className="py-3 font-semibold text-white">{item.nome}</td>
                  <td className="py-3">{item.quantidade}</td>
                  <td className="py-3">{item.motivo}</td>
                  <td className="py-3">
                    <button className="text-blue-400 hover:text-blue-300 font-semibold text-sm">Ver</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }

    return (
      <div className="overflow-x-auto">
        <table className="w-full text-left text-gray-300">
          <thead>
            <tr className="border-b border-slate-600">
              <th className="pb-3 font-semibold text-white">Produto</th>
              <th className="pb-3 font-semibold text-white">Quantidade</th>
              <th className="pb-3 font-semibold text-white">Mínimo</th>
              <th className="pb-3 font-semibold text-white">Status</th>
              <th className="pb-3 font-semibold text-white">Ações</th>
            </tr>
          </thead>
          <tbody>
            {dados.map((item: any) => (
              <tr key={item.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                <td className="py-3 font-semibold text-white">{item.nome}</td>
                <td className="py-3">{item.quantidade}</td>
                <td className="py-3">{item.minimo}</td>
                <td className="py-3">
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold text-white ${getStatusColor(item.status)}`}>
                    {item.status}
                  </span>
                </td>
                <td className="py-3">
                  <button className="text-blue-400 hover:text-blue-300 font-semibold text-sm">Editar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const tiposInventario = [
    { id: 'produtos', label: 'Inventário de Produtos', icon: Package },
    { id: 'tintas', label: 'Inventário de Tintas', icon: Package },
    { id: 'ferramentas', label: 'Inventário de Ferramentas', icon: Package },
    { id: 'escritorio', label: 'Inventário de Escritório', icon: Package },
    { id: 'danificados', label: 'Produtos Danificados', icon: Package },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Inventário</h2>
        <button
          onClick={() => generatePDF('inventario-content', 'inventario', 'Relatório de Inventário - TRANSTEC WORLD')}
          className="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Gerar PDF
        </button>
      </div>

      <div id="inventario-content" className="space-y-6">

      <div className="grid grid-cols-5 gap-3">
        {tiposInventario.map((tipo) => (
          <button
            key={tipo.id}
            onClick={() => setTipoInventario(tipo.id)}
            className={`p-4 rounded-lg font-semibold transition ${
              tipoInventario === tipo.id
                ? 'bg-cyan-600 text-white border-2 border-cyan-400'
                : 'bg-slate-700 hover:bg-slate-600 text-gray-300 border border-slate-600'
            }`}
          >
            <p className="text-sm">{tipo.label}</p>
          </button>
        ))}
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-white">
            {tiposInventario.find(t => t.id === tipoInventario)?.label}
          </h3>
          <button className="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Adicionar Item
          </button>
        </div>

        {renderInventario()}
      </div>

      <div className="grid grid-cols-5 gap-4">
        <div className="bg-gradient-to-br from-blue-700 to-blue-800 p-6 rounded-xl border border-blue-600">
          <p className="text-blue-200 text-sm">Produtos</p>
          <p className="text-2xl font-bold text-white mt-2">3</p>
        </div>
        <div className="bg-gradient-to-br from-purple-700 to-purple-800 p-6 rounded-xl border border-purple-600">
          <p className="text-purple-200 text-sm">Tintas</p>
          <p className="text-2xl font-bold text-white mt-2">3</p>
        </div>
        <div className="bg-gradient-to-br from-amber-700 to-amber-800 p-6 rounded-xl border border-amber-600">
          <p className="text-amber-200 text-sm">Ferramentas</p>
          <p className="text-2xl font-bold text-white mt-2">3</p>
        </div>
        <div className="bg-gradient-to-br from-green-700 to-green-800 p-6 rounded-xl border border-green-600">
          <p className="text-green-200 text-sm">Escritório</p>
          <p className="text-2xl font-bold text-white mt-2">3</p>
        </div>
        <div className="bg-gradient-to-br from-red-700 to-red-800 p-6 rounded-xl border border-red-600">
          <p className="text-red-200 text-sm">Danificados</p>
          <p className="text-2xl font-bold text-white mt-2">3</p>
        </div>
      </div>
      </div>
    </div>
  );
}
