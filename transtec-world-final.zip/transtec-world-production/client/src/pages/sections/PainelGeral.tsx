import React, { useState } from 'react';
import { BarChart3, Package, FileText, Printer, Archive, Download } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';

export default function PainelGeralPage() {
  const { generatePDF } = usePDFGenerator();
  const categorias = [
    { id: 'inventarios', label: 'Inventários', icon: Package, cor: 'from-blue-600 to-blue-700', count: 5 },
    { id: 'movimentacoes', label: 'Movimentações', icon: BarChart3, cor: 'from-purple-600 to-purple-700', count: 12 },
    { id: 'pedidos', label: 'Pedidos e Controle', icon: FileText, cor: 'from-amber-600 to-amber-700', count: 8 },
    { id: 'impressoes', label: 'Impressões Diárias', icon: Printer, cor: 'from-green-600 to-green-700', count: 3 },
    { id: 'documentos', label: 'Documentos de Apoio', icon: Archive, cor: 'from-red-600 to-red-700', count: 15 },
  ];

  const [categoriaSelecionada, setCategoriaSelecionada] = useState<string | null>(null);

  const renderConteudoCategoria = (id: string) => {
    switch(id) {
      case 'inventarios':
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white">Inventários</h3>
            <div className="space-y-3">
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Inventário de Produtos</p>
                <p className="text-sm text-gray-400">Último atualizado: 2025-04-16</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Inventário de Tintas</p>
                <p className="text-sm text-gray-400">Último atualizado: 2025-04-16</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Inventário de Ferramentas</p>
                <p className="text-sm text-gray-400">Último atualizado: 2025-04-15</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Inventário de Escritório</p>
                <p className="text-sm text-gray-400">Último atualizado: 2025-04-14</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Inventário de Produtos Danificados</p>
                <p className="text-sm text-gray-400">Último atualizado: 2025-04-16</p>
              </div>
            </div>
          </div>
        );
      case 'movimentacoes':
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white">Movimentações</h3>
            <div className="space-y-3">
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Entradas de Produtos</p>
                <p className="text-sm text-gray-400">12 movimentações hoje</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Saídas de Produtos</p>
                <p className="text-sm text-gray-400">8 movimentações hoje</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Retiradas de Ferramentas</p>
                <p className="text-sm text-gray-400">5 retiradas hoje</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Movimentação de Thinner</p>
                <p className="text-sm text-gray-400">Última movimentação: 2025-04-16</p>
              </div>
            </div>
          </div>
        );
      case 'pedidos':
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white">Pedidos e Controle</h3>
            <div className="space-y-3">
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Pedidos de Oficina</p>
                <p className="text-sm text-gray-400">3 pedidos pendentes</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Pedidos Quinzenais - Cozinhas</p>
                <p className="text-sm text-gray-400">Próximo pedido: 2025-04-25</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Pedidos Quinzenais - Escritórios</p>
                <p className="text-sm text-gray-400">Próximo pedido: 2025-04-25</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Retirada de Pedidos</p>
                <p className="text-sm text-gray-400">2 pedidos aguardando retirada</p>
              </div>
            </div>
          </div>
        );
      case 'impressoes':
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white">Impressões Diárias</h3>
            <div className="space-y-3">
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Check-List Diário</p>
                <p className="text-sm text-gray-400">Imprimir relatório do dia</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Controle de Acesso</p>
                <p className="text-sm text-gray-400">Imprimir lista de acesso</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Relatório de Movimentações</p>
                <p className="text-sm text-gray-400">Imprimir movimentações do dia</p>
              </div>
            </div>
          </div>
        );
      case 'documentos':
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white">Documentos de Apoio</h3>
            <div className="space-y-3">
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Procedimentos Operacionais</p>
                <p className="text-sm text-gray-400">15 documentos disponíveis</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Manuais de Equipamento</p>
                <p className="text-sm text-gray-400">Acesso a documentação técnica</p>
              </div>
              <div className="bg-slate-600 p-4 rounded-lg">
                <p className="font-semibold text-white">Suporte Outlook</p>
                <p className="text-sm text-gray-400">Guia de uso de e-mails</p>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Painel Geral</h2>
        <button
          onClick={() => generatePDF('painel-geral-content', 'painel-geral', 'Painel Geral - TRANSTEC WORLD')}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Gerar PDF
        </button>
      </div>

      <div id="painel-geral-content" className="space-y-6">

      <div className="grid grid-cols-5 gap-4">
        {categorias.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setCategoriaSelecionada(categoriaSelecionada === cat.id ? null : cat.id)}
            className={`p-6 rounded-xl border transition ${
              categoriaSelecionada === cat.id
                ? `bg-gradient-to-br ${cat.cor} border-white shadow-lg`
                : 'bg-gradient-to-br from-slate-700 to-slate-800 border-slate-600 hover:border-slate-500'
            }`}
          >
            <cat.icon className={`w-8 h-8 mb-3 ${categoriaSelecionada === cat.id ? 'text-white' : 'text-blue-400'}`} />
            <p className={`font-semibold ${categoriaSelecionada === cat.id ? 'text-white' : 'text-white'}`}>{cat.label}</p>
            <p className={`text-sm ${categoriaSelecionada === cat.id ? 'text-white' : 'text-gray-400'}`}>{cat.count} itens</p>
          </button>
        ))}
      </div>

      {categoriaSelecionada && (
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
          {renderConteudoCategoria(categoriaSelecionada)}
        </div>
      )}

        <div className="grid grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-blue-700 to-blue-800 p-6 rounded-xl border border-blue-600">
            <p className="text-blue-200 text-sm">Movimentações Hoje</p>
            <p className="text-3xl font-bold text-white mt-2">25</p>
          </div>
          <div className="bg-gradient-to-br from-purple-700 to-purple-800 p-6 rounded-xl border border-purple-600">
            <p className="text-purple-200 text-sm">Inventários Ativos</p>
            <p className="text-3xl font-bold text-white mt-2">5</p>
          </div>
          <div className="bg-gradient-to-br from-amber-700 to-amber-800 p-6 rounded-xl border border-amber-600">
            <p className="text-amber-200 text-sm">Pedidos Pendentes</p>
            <p className="text-3xl font-bold text-white mt-2">3</p>
          </div>
        </div>
      </div>
    </div>
  );
}
