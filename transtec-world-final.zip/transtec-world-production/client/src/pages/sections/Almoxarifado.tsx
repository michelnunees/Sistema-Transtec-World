import React, { useState } from 'react';
import { Warehouse, Plus, Download, Search } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';

export default function AlmoxarifadoPage() {
  const { generatePDF } = usePDFGenerator();
  const [filtro, setFiltro] = useState('');

  const estoque = [
    { id: 1, codigo: 'ALM-001', item: 'EPI - Capacete de Segurança', categoria: 'Segurança', quantidade: 45, unidade: 'UN', status: 'OK' },
    { id: 2, codigo: 'ALM-002', item: 'EPI - Luvas de Raspa', categoria: 'Segurança', quantidade: 12, unidade: 'PAR', status: 'Crítico' },
    { id: 3, codigo: 'ALM-003', item: 'Eletrodo 6013 3.25mm', categoria: 'Consumíveis', quantidade: 150, unidade: 'KG', status: 'OK' },
    { id: 4, codigo: 'ALM-004', item: 'Disco de Corte 4.1/2"', categoria: 'Consumíveis', quantidade: 85, unidade: 'UN', status: 'OK' },
    { id: 5, codigo: 'ALM-005', item: 'Graxa Chassis CA-2', categoria: 'Lubrificantes', quantidade: 5, unidade: 'BALDE', status: 'Crítico' },
  ];

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'OK': return 'bg-green-600';
      case 'Crítico': return 'bg-red-600';
      default: return 'bg-slate-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Warehouse className="w-8 h-8 text-blue-400" />
          <h2 className="text-3xl font-bold text-white">Almoxarifado</h2>
        </div>
        <button
          onClick={() => generatePDF('almoxarifado-content', 'almoxarifado', 'Relatório de Almoxarifado - TRANSTEC WORLD')}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Gerar PDF
        </button>
      </div>

      <div className="bg-slate-700 p-4 rounded-xl border border-slate-600 flex items-center gap-4">
        <Search className="w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Buscar por código ou nome do item..."
          value={filtro}
          onChange={(e) => setFiltro(e.target.value)}
          className="bg-transparent border-none text-white focus:ring-0 w-full"
        />
      </div>

      <div id="almoxarifado-content" className="space-y-6">
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-white">Controle de Estoque</h3>
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Novo Item
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-gray-300">
              <thead>
                <tr className="border-b border-slate-600">
                  <th className="pb-3 font-semibold text-white">Código</th>
                  <th className="pb-3 font-semibold text-white">Item</th>
                  <th className="pb-3 font-semibold text-white">Categoria</th>
                  <th className="pb-3 font-semibold text-white">Qtd.</th>
                  <th className="pb-3 font-semibold text-white">Unid.</th>
                  <th className="pb-3 font-semibold text-white">Status</th>
                  <th className="pb-3 font-semibold text-white">Ações</th>
                </tr>
              </thead>
              <tbody>
                {estoque
                  .filter(i => i.item.toLowerCase().includes(filtro.toLowerCase()) || i.codigo.toLowerCase().includes(filtro.toLowerCase()))
                  .map((item) => (
                  <tr key={item.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                    <td className="py-3 font-mono text-sm">{item.codigo}</td>
                    <td className="py-3 font-semibold text-white">{item.item}</td>
                    <td className="py-3">{item.categoria}</td>
                    <td className="py-3">{item.quantidade}</td>
                    <td className="py-3">{item.unidade}</td>
                    <td className="py-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${getStatusColor(item.status)}`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="py-3">
                      <button className="text-blue-400 hover:text-blue-300 font-semibold text-sm">Movimentar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-blue-700 to-blue-800 p-6 rounded-xl border border-blue-600">
            <p className="text-blue-200 text-sm">Total de Itens</p>
            <p className="text-2xl font-bold text-white mt-2">5</p>
          </div>
          <div className="bg-gradient-to-br from-amber-700 to-amber-800 p-6 rounded-xl border border-amber-600">
            <p className="text-amber-200 text-sm">Itens Críticos</p>
            <p className="text-2xl font-bold text-white mt-2">2</p>
          </div>
          <div className="bg-gradient-to-br from-green-700 to-green-800 p-6 rounded-xl border border-green-600">
            <p className="text-green-200 text-sm">Movimentações (Hoje)</p>
            <p className="text-2xl font-bold text-white mt-2">12</p>
          </div>
        </div>
      </div>
    </div>
  );
}
