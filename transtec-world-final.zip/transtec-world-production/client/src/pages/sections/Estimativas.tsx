import React, { useState } from 'react';
import { Clipboard, Plus, Download } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';

export default function EstimasPage() {
  const { generatePDF } = usePDFGenerator();
  const [estimativas, setEstimativas] = useState([
    { id: 1, armador: 'HLBU 9005234', data: '2025-04-16', turno: 'Dia', classificacao: 'CF', observacao: 'Lavador 1' },
    { id: 2, armador: 'HLBU 9005235', data: '2025-04-16', turno: 'Noite', classificacao: 'CG', observacao: 'Lavador 2' },
    { id: 3, armador: 'HLBU 9005236', data: '2025-04-15', turno: 'Dia', classificacao: 'CF', observacao: '' },
  ]);

  const [formData, setFormData] = useState({
    armador: '',
  });

  const [resultados, setResultados] = useState<any>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const buscarArmador = (e: React.FormEvent) => {
    e.preventDefault();
    const encontrado = estimativas.find(e => e.armador.toLowerCase() === formData.armador.toLowerCase());
    if (encontrado) {
      setResultados(encontrado);
    } else {
      setResultados(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Estimativas</h2>
        <button
          onClick={() => generatePDF('estimativas-content', 'estimativas', 'Relatório de Estimativas - TRANSTEC WORLD')}
          className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Gerar PDF
        </button>
      </div>

      <div id="estimativas-content" className="space-y-6">

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <form onSubmit={buscarArmador} className="space-y-4">
          <h3 className="text-lg font-bold text-white mb-4">Buscar Armador</h3>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Armador</label>
            <input
              type="text"
              name="armador"
              value={formData.armador}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              placeholder="Ex: HLBU 9005234"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Buscar Estimativa
          </button>
        </form>
      </div>

      {resultados && (
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
          <h3 className="text-xl font-bold text-white mb-6">Resultado da Busca</h3>

          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-gray-400 text-sm">Armador</p>
              <p className="text-white font-semibold text-lg">{resultados.armador}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Data</p>
              <p className="text-white font-semibold text-lg">{resultados.data}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Turno</p>
              <p className="text-white font-semibold text-lg">{resultados.turno}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Classificação</p>
              <p className={`font-semibold text-lg ${resultados.classificacao === 'CF' ? 'text-blue-400' : 'text-purple-400'}`}>
                {resultados.classificacao} - {resultados.classificacao === 'CF' ? 'Alimento' : 'Carga Geral'}
              </p>
            </div>
            <div className="col-span-2">
              <p className="text-gray-400 text-sm">Observação</p>
              <p className="text-white font-semibold">{resultados.observacao || 'Nenhuma observação'}</p>
            </div>
          </div>

          <button className="w-full mt-6 bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg font-semibold transition">
            Confirmar Estimativa
          </button>
        </div>
      )}

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Clipboard className="w-6 h-6 text-amber-400" />
          Estimativas Recentes
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-gray-300">
            <thead>
              <tr className="border-b border-slate-600">
                <th className="pb-3 font-semibold text-white">Armador</th>
                <th className="pb-3 font-semibold text-white">Data</th>
                <th className="pb-3 font-semibold text-white">Turno</th>
                <th className="pb-3 font-semibold text-white">Classificação</th>
                <th className="pb-3 font-semibold text-white">Observação</th>
              </tr>
            </thead>
            <tbody>
              {estimativas.map((est) => (
                <tr key={est.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                  <td className="py-3 font-semibold text-white">{est.armador}</td>
                  <td className="py-3">{est.data}</td>
                  <td className="py-3">{est.turno}</td>
                  <td className="py-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold text-white ${
                      est.classificacao === 'CF' ? 'bg-blue-600' : 'bg-purple-600'
                    }`}>
                      {est.classificacao}
                    </span>
                  </td>
                  <td className="py-3">{est.observacao || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      </div>
    </div>
  );
}
