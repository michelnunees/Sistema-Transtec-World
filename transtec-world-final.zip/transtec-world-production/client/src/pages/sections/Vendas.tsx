import React, { useState } from 'react';
import { Package, Plus, DollarSign } from 'lucide-react';

export default function VendasPage() {
  const [vendas, setVendas] = useState([
    { id: 1, codigo: 'VENDA-2025-001', cliente: 'Empresa A', servico: 'Transporte', valor: 5000, data: '2025-04-16', status: 'Pago' },
    { id: 2, codigo: 'VENDA-2025-002', cliente: 'Empresa B', servico: 'Armazenagem', valor: 3500, data: '2025-04-15', status: 'Pendente' },
    { id: 3, codigo: 'VENDA-2025-003', cliente: 'Empresa C', servico: 'Locação', valor: 2000, data: '2025-04-14', status: 'Pago' },
  ]);

  const [formData, setFormData] = useState({
    cliente: '',
    servico: '',
    descricao: '',
    valor: '',
    dataInicio: '',
    dataFim: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Venda/Locação registrada:', formData);
    setFormData({
      cliente: '',
      servico: '',
      descricao: '',
      valor: '',
      dataInicio: '',
      dataFim: '',
    });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Vendas e Locações</h2>
      
      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <form onSubmit={handleSubmit} className="space-y-4">
          <h3 className="text-lg font-bold text-white">Registrar Venda/Locação</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Cliente</label>
              <input 
                type="text" 
                name="cliente"
                value={formData.cliente}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500" 
                placeholder="Nome da empresa" 
                required
              />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Tipo de Serviço</label>
              <select 
                name="servico"
                value={formData.servico}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                required
              >
                <option value="">Selecionar...</option>
                <option value="Transporte">Transporte</option>
                <option value="Armazenagem">Armazenagem</option>
                <option value="Locação">Locação de Equipamentos</option>
                <option value="Consultoria">Consultoria</option>
                <option value="Outro">Outro</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Descrição</label>
            <textarea 
              name="descricao"
              value={formData.descricao}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500" 
              placeholder="Detalhes do serviço..." 
              rows={3}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Valor (R$)</label>
              <input 
                type="number" 
                name="valor"
                value={formData.valor}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500" 
                placeholder="0.00" 
                required
              />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Período</label>
              <div className="flex gap-2">
                <input 
                  type="date" 
                  name="dataInicio"
                  value={formData.dataInicio}
                  onChange={handleInputChange}
                  className="flex-1 bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500" 
                  required
                />
                <input 
                  type="date" 
                  name="dataFim"
                  value={formData.dataFim}
                  onChange={handleInputChange}
                  className="flex-1 bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500" 
                  required
                />
              </div>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-pink-600 hover:bg-pink-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Registrar Venda/Locação
          </button>
        </form>
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Package className="w-6 h-6 text-pink-400" />
          Histórico de Vendas e Locações
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-gray-300">
            <thead>
              <tr className="border-b border-slate-600">
                <th className="pb-3 font-semibold text-white">Código</th>
                <th className="pb-3 font-semibold text-white">Cliente</th>
                <th className="pb-3 font-semibold text-white">Serviço</th>
                <th className="pb-3 font-semibold text-white">Valor</th>
                <th className="pb-3 font-semibold text-white">Data</th>
                <th className="pb-3 font-semibold text-white">Status</th>
              </tr>
            </thead>
            <tbody>
              {vendas.map((venda) => (
                <tr key={venda.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                  <td className="py-3 font-semibold text-white">{venda.codigo}</td>
                  <td className="py-3">{venda.cliente}</td>
                  <td className="py-3">{venda.servico}</td>
                  <td className="py-3 flex items-center gap-1 font-semibold text-pink-400">
                    <DollarSign className="w-4 h-4" />
                    {venda.valor.toLocaleString('pt-BR')}
                  </td>
                  <td className="py-3">{venda.data}</td>
                  <td className="py-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      venda.status === 'Pago' ? 'bg-green-600 text-white' : 'bg-amber-600 text-white'
                    }`}>
                      {venda.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-6 rounded-xl border border-slate-600">
          <p className="text-gray-400 text-sm">Total de Vendas</p>
          <p className="text-3xl font-bold text-pink-400 mt-2">R$ 10.500</p>
          <p className="text-xs text-gray-500 mt-2">Últimos 30 dias</p>
        </div>
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-6 rounded-xl border border-slate-600">
          <p className="text-gray-400 text-sm">Vendas Pagas</p>
          <p className="text-3xl font-bold text-green-400 mt-2">R$ 7.000</p>
          <p className="text-xs text-gray-500 mt-2">2 transações</p>
        </div>
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-6 rounded-xl border border-slate-600">
          <p className="text-gray-400 text-sm">Vendas Pendentes</p>
          <p className="text-3xl font-bold text-amber-400 mt-2">R$ 3.500</p>
          <p className="text-xs text-gray-500 mt-2">1 transação</p>
        </div>
      </div>
    </div>
  );
}
