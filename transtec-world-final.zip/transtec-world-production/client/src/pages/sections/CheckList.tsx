import React, { useState } from 'react';
import { CheckSquare, Plus, Download } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';

export default function CheckListPage() {
  const { generatePDF } = usePDFGenerator();
  const [itens, setItens] = useState([
    { id: 1, nome: 'Controle de Acesso', concluido: false, data: '2025-04-16' },
    { id: 2, nome: 'Check-list Manual', concluido: false, data: '2025-04-16' },
    { id: 3, nome: 'Check-list Visual', concluido: false, data: '2025-04-16' },
    { id: 4, nome: 'Retirada de Ferramenta', concluido: false, data: '2025-04-16' },
    { id: 5, nome: 'Retirada de Pedido', concluido: false, data: '2025-04-16' },
    { id: 6, nome: 'Impressões Diárias', concluido: false, data: '2025-04-16' },
  ]);

  const [novoItem, setNovoItem] = useState('');

  const toggleItem = (id: number) => {
    setItens(prev => prev.map(item => 
      item.id === id ? { ...item, concluido: !item.concluido } : item
    ));
  };

  const adicionarItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (novoItem.trim()) {
      setItens(prev => [...prev, {
        id: Math.max(...prev.map(i => i.id), 0) + 1,
        nome: novoItem,
        concluido: false,
        data: new Date().toLocaleDateString('pt-BR'),
      }]);
      setNovoItem('');
    }
  };

  const deletarItem = (id: number) => {
    setItens(prev => prev.filter(item => item.id !== id));
  };

  const concluidos = itens.filter(i => i.concluido).length;
  const total = itens.length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Check-List Diário</h2>
        <button
          onClick={() => generatePDF('checklist-content', 'checklist', 'Check-List Diário - TRANSTEC WORLD')}
          className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Gerar PDF
        </button>
      </div>

      <div id="checklist-content" className="space-y-6">

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <form onSubmit={adicionarItem} className="space-y-4">
          <h3 className="text-lg font-bold text-white">Adicionar Item ao Check-List</h3>
          
          <div className="flex gap-2">
            <input
              type="text"
              value={novoItem}
              onChange={(e) => setNovoItem(e.target.value)}
              className="flex-1 bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              placeholder="Descrever novo item..."
              required
            />
            <button
              type="submit"
              className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold transition flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Adicionar
            </button>
          </div>
        </form>
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-white">Itens do Check-List</h3>
          <div className="text-right">
            <p className="text-gray-400 text-sm">Progresso</p>
            <p className="text-2xl font-bold text-purple-400">{concluidos}/{total}</p>
          </div>
        </div>

        <div className="w-full bg-slate-600 rounded-full h-3 mb-6">
          <div
            className="bg-purple-600 h-3 rounded-full transition-all"
            style={{ width: `${total > 0 ? (concluidos / total) * 100 : 0}%` }}
          />
        </div>

        <div className="space-y-3">
          {itens.map((item) => (
            <div
              key={item.id}
              className="bg-slate-600 p-4 rounded-lg hover:bg-slate-500 transition flex items-center gap-3"
            >
              <button
                onClick={() => toggleItem(item.id)}
                className={`flex-shrink-0 w-6 h-6 rounded border-2 flex items-center justify-center transition ${
                  item.concluido
                    ? 'bg-purple-600 border-purple-600'
                    : 'border-gray-400 hover:border-purple-400'
                }`}
              >
                {item.concluido && (
                  <CheckSquare className="w-4 h-4 text-white" />
                )}
              </button>
              <div className="flex-1">
                <p className={`font-semibold ${item.concluido ? 'text-gray-400 line-through' : 'text-white'}`}>
                  {item.nome}
                </p>
                <p className="text-xs text-gray-500">{item.data}</p>
              </div>
              <button 
                onClick={() => deletarItem(item.id)}
                className="text-red-400 hover:text-red-300 font-semibold text-sm transition"
              >
                Deletar
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-purple-700 to-purple-800 p-6 rounded-xl border border-purple-600">
          <p className="text-purple-200 text-sm">Itens Concluídos</p>
          <p className="text-3xl font-bold text-white mt-2">{concluidos}</p>
        </div>
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-6 rounded-xl border border-slate-600">
          <p className="text-gray-400 text-sm">Itens Pendentes</p>
          <p className="text-3xl font-bold text-white mt-2">{total - concluidos}</p>
        </div>
      </div>
      </div>
    </div>
  );
}
