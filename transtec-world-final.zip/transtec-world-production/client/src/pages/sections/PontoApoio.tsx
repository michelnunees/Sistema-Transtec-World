import React, { useState } from 'react';
import { MapPin, Plus, Users } from 'lucide-react';

export default function PontoApoioPage() {
  const [pontos, setPontos] = useState([
    { id: 1, nome: 'Ponto de Apoio Centro', endereco: 'Av. Paulista, 1000', cidade: 'São Paulo', telefone: '(11) 3000-0000', operadores: 5 },
    { id: 2, nome: 'Ponto de Apoio Zona Leste', endereco: 'Rua das Flores, 500', cidade: 'São Paulo', telefone: '(11) 3111-1111', operadores: 3 },
    { id: 3, nome: 'Ponto de Apoio Zona Sul', endereco: 'Av. Brasil, 2000', cidade: 'São Paulo', telefone: '(11) 3222-2222', operadores: 4 },
  ]);

  const [formData, setFormData] = useState({
    nome: '',
    endereco: '',
    cidade: '',
    telefone: '',
    gerente: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Ponto de apoio criado:', formData);
    setFormData({
      nome: '',
      endereco: '',
      cidade: '',
      telefone: '',
      gerente: '',
    });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Pontos de Apoio</h2>
      
      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <form onSubmit={handleSubmit} className="space-y-4">
          <h3 className="text-lg font-bold text-white">Novo Ponto de Apoio</h3>
          
          <div>
            <label className="block text-gray-300 font-semibold mb-2">Nome do Ponto</label>
            <input 
              type="text" 
              name="nome"
              value={formData.nome}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500" 
              placeholder="Ex: Ponto de Apoio Centro" 
              required
            />
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Endereço</label>
            <input 
              type="text" 
              name="endereco"
              value={formData.endereco}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500" 
              placeholder="Rua, número, complemento" 
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Cidade</label>
              <input 
                type="text" 
                name="cidade"
                value={formData.cidade}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500" 
                placeholder="São Paulo" 
                required
              />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Telefone</label>
              <input 
                type="tel" 
                name="telefone"
                value={formData.telefone}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500" 
                placeholder="(11) 0000-0000" 
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Gerente Responsável</label>
            <input 
              type="text" 
              name="gerente"
              value={formData.gerente}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500" 
              placeholder="Nome do gerente" 
              required
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Criar Ponto de Apoio
          </button>
        </form>
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <MapPin className="w-6 h-6 text-cyan-400" />
          Pontos de Apoio Cadastrados
        </h3>
        
        <div className="space-y-4">
          {pontos.map((ponto) => (
            <div key={ponto.id} className="bg-slate-600 p-6 rounded-lg hover:bg-slate-500 transition">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <p className="font-semibold text-white text-lg">{ponto.nome}</p>
                  <p className="text-sm text-gray-400">{ponto.endereco}</p>
                </div>
                <span className="bg-cyan-600 text-white px-3 py-1 rounded-full text-sm font-semibold">Ativo</span>
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-gray-400">Cidade</p>
                  <p className="text-white font-semibold">{ponto.cidade}</p>
                </div>
                <div>
                  <p className="text-gray-400">Telefone</p>
                  <p className="text-white font-semibold">{ponto.telefone}</p>
                </div>
                <div>
                  <p className="text-gray-400 flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    Operadores
                  </p>
                  <p className="text-white font-semibold">{ponto.operadores}</p>
                </div>
              </div>

              <div className="mt-4 flex gap-2">
                <button className="text-cyan-400 hover:text-cyan-300 font-semibold text-sm">Editar</button>
                <button className="text-red-400 hover:text-red-300 font-semibold text-sm">Deletar</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
