import React, { useState } from 'react';
import { Lock, CheckCircle, AlertCircle } from 'lucide-react';

export default function EncerramentoPage() {
  const [operacoes, setOperacoes] = useState([
    { id: 1, codigo: 'OP-2025-001', status: 'Pendente', dataInicio: '2025-04-10', dataFim: '2025-04-16' },
    { id: 2, codigo: 'OP-2025-002', status: 'Encerrado', dataInicio: '2025-04-05', dataFim: '2025-04-12' },
    { id: 3, codigo: 'OP-2025-003', status: 'Pendente', dataInicio: '2025-04-12', dataFim: '2025-04-18' },
  ]);

  const [selectedOp, setSelectedOp] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    observacoes: '',
    documentacao: '',
    assinatura: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleEncerrar = (id: number) => {
    setSelectedOp(id);
    setFormData({
      observacoes: '',
      documentacao: '',
      assinatura: '',
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedOp) {
      setOperacoes(prev => prev.map(op => 
        op.id === selectedOp ? { ...op, status: 'Encerrado' } : op
      ));
      setSelectedOp(null);
      setFormData({
        observacoes: '',
        documentacao: '',
        assinatura: '',
      });
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Encerramento de Operações</h2>
      
      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <AlertCircle className="w-6 h-6 text-amber-400" />
          Operações em Andamento
        </h3>
        
        <div className="space-y-3">
          {operacoes.filter(op => op.status === 'Pendente').map((op) => (
            <div key={op.id} className="bg-slate-600 p-4 rounded-lg hover:bg-slate-500 transition flex justify-between items-center">
              <div>
                <p className="font-semibold text-white">{op.codigo}</p>
                <p className="text-sm text-gray-400">{op.dataInicio} até {op.dataFim}</p>
              </div>
              <button
                onClick={() => handleEncerrar(op.id)}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
              >
                <Lock className="w-4 h-4" />
                Encerrar
              </button>
            </div>
          ))}
        </div>
      </div>

      {selectedOp && (
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
          <h3 className="text-xl font-bold text-white mb-6">Formulário de Encerramento</h3>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Observações Finais</label>
              <textarea 
                name="observacoes"
                value={formData.observacoes}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" 
                placeholder="Descreva o status final da operação..." 
                rows={4}
                required
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-2">Documentação Completa</label>
              <select 
                name="documentacao"
                value={formData.documentacao}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                required
              >
                <option value="">Selecionar...</option>
                <option value="Sim">Sim, documentação completa</option>
                <option value="Parcial">Parcial, faltam documentos</option>
                <option value="Não">Não, documentação incompleta</option>
              </select>
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-2">Assinatura Digital</label>
              <input 
                type="text" 
                name="assinatura"
                value={formData.assinatura}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" 
                placeholder="Seu nome/ID" 
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button 
                type="button"
                onClick={() => setSelectedOp(null)}
                className="bg-slate-600 hover:bg-slate-700 text-white py-3 rounded-lg font-semibold transition"
              >
                Cancelar
              </button>
              <button 
                type="submit"
                className="bg-red-600 hover:bg-red-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2"
              >
                <Lock className="w-5 h-5" />
                Confirmar Encerramento
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <CheckCircle className="w-6 h-6 text-green-400" />
          Operações Encerradas
        </h3>
        
        <div className="space-y-3">
          {operacoes.filter(op => op.status === 'Encerrado').map((op) => (
            <div key={op.id} className="bg-slate-600 p-4 rounded-lg flex justify-between items-center">
              <div>
                <p className="font-semibold text-white">{op.codigo}</p>
                <p className="text-sm text-gray-400">{op.dataInicio} até {op.dataFim}</p>
              </div>
              <span className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold">Encerrado</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
