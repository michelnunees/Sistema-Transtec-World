import React, { useState } from 'react';
import { Plus, Download, Upload, Mail, Trash2, Edit2, Check, X } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';
import * as XLSX from 'xlsx';

interface Maquina {
  id: number;
  tipo: string;
  numero: string;
  status: 'bom' | 'parada';
  observacoes: string;
  data: string;
  responsavel: string;
}

export default function CheckListMaquinasPage() {
  const { generatePDF } = usePDFGenerator();
  const [maquinas, setMaquinas] = useState<Maquina[]>([
    { id: 1, tipo: 'TA', numero: '128', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 2, tipo: 'TA', numero: '129', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 3, tipo: 'TA', numero: '130', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 4, tipo: 'TA', numero: '131', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 5, tipo: 'TA', numero: '132', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 6, tipo: 'TA', numero: '133', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 7, tipo: 'TA', numero: '134', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 8, tipo: 'TA', numero: '135', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 9, tipo: 'TA', numero: '136', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
    { id: 10, tipo: 'TA', numero: '137', status: 'bom', observacoes: '', data: new Date().toISOString().split('T')[0], responsavel: 'Admin' },
  ]);

  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [editandoDados, setEditandoDados] = useState<Maquina | null>(null);

  const atualizarStatus = (id: number, novoStatus: 'bom' | 'parada') => {
    setMaquinas(prev => prev.map(m => 
      m.id === id ? { ...m, status: novoStatus } : m
    ));
  };

  const iniciarEdicao = (maquina: Maquina) => {
    setEditandoId(maquina.id);
    setEditandoDados({ ...maquina });
  };

  const salvarEdicao = () => {
    if (editandoDados) {
      setMaquinas(prev => prev.map(m => 
        m.id === editandoDados.id ? editandoDados : m
      ));
      setEditandoId(null);
      setEditandoDados(null);
    }
  };

  const cancelarEdicao = () => {
    setEditandoId(null);
    setEditandoDados(null);
  };

  const deletarMaquina = (id: number) => {
    if (confirm('Tem certeza que deseja deletar esta máquina?')) {
      setMaquinas(prev => prev.filter(m => m.id !== id));
    }
  };

  const exportarExcel = () => {
    const dados = maquinas.map(m => ({
      'Máquina': `${m.tipo} ${m.numero}`,
      'Status': m.status === 'bom' ? 'Bom' : 'Parada',
      'Observações': m.observacoes,
    }));

    const worksheet = XLSX.utils.json_to_sheet(dados);
    
    // Configurar largura das colunas
    worksheet['!cols'] = [
      { wch: 15 },
      { wch: 12 },
      { wch: 40 }
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Check-List Máquinas');
    XLSX.writeFile(workbook, `checklist-maquinas-${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const importarExcel = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[];

        const novasMaquinas: Maquina[] = jsonData.map((row, idx) => {
          const maquinaStr = (row['Máquina'] || row['maquina'] || '').toString();
          const [tipo, numero] = maquinaStr.split(' ');
          
          const statusStr = (row['Status'] || row['status'] || 'bom').toLowerCase();
          let status: 'bom' | 'parada' = 'bom';
          if (statusStr === 'parada') status = 'parada';
          
          return {
            id: Math.max(...maquinas.map(m => m.id), 0) + idx + 1,
            tipo: tipo || 'TA',
            numero: numero || '',
            status: status,
            observacoes: row['Observações'] || row['observacoes'] || '',
            data: new Date().toISOString().split('T')[0],
            responsavel: 'Admin',
          };
        });

        setMaquinas(novasMaquinas);
        alert('Planilha importada com sucesso!');
      } catch (error) {
        alert('Erro ao importar planilha: ' + error);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const enviarPorEmail = () => {
    const relatorio = maquinas.map(m => 
      `${m.tipo} ${m.numero}: ${m.status === 'bom' ? '✓ Bom' : '✗ Parada'} - ${m.observacoes || 'Sem observações'}`
    ).join('\n');

    const assunto = `Check-List Diário de Máquinas - ${new Date().toLocaleDateString('pt-BR')}`;
    const corpo = `Relatório de Check-List Diário de Máquinas\n\nData: ${new Date().toLocaleDateString('pt-BR')}\nTerminal: Terminal Continental\n\n${relatorio}\n\n---\nRelatório gerado pelo TRANSTEC WORLD`;

    // Redirecionar para Outlook Web
    const outlookUrl = `https://outlook.office.com/mail/deeplink/compose?to=&subject=${encodeURIComponent(assunto)}&body=${encodeURIComponent(corpo)}`;
    window.open(outlookUrl, '_blank');
  };

  const statusCor = (status: string) => {
    switch(status) {
      case 'bom': return 'bg-green-600 hover:bg-green-700';
      case 'parada': return 'bg-red-600 hover:bg-red-700';
      default: return 'bg-gray-600 hover:bg-gray-700';
    }
  };

  const statusTexto = (status: string) => {
    switch(status) {
      case 'bom': return 'Bom';
      case 'parada': return 'Parada';
      default: return 'Desconhecido';
    }
  };

  const bom = maquinas.filter(m => m.status === 'bom').length;
  const parada = maquinas.filter(m => m.status === 'parada').length;

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Check-List Diário de Máquinas</h2>
          <p className="text-gray-400 text-sm">Inspeção diária de empilhadeiras - {new Date().toLocaleDateString('pt-BR')}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => generatePDF('checklist-maquinas-content', 'checklist-maquinas', 'Check-List Diário de Máquinas')}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Gerar PDF
          </button>
          <button
            onClick={exportarExcel}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Exportar Excel
          </button>
          <label className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2 cursor-pointer">
            <Upload className="w-4 h-4" />
            Importar Excel
            <input type="file" accept=".xlsx,.xls" onChange={importarExcel} className="hidden" />
          </label>
          <button
            onClick={enviarPorEmail}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
          >
            <Mail className="w-4 h-4" />
            Enviar Email
          </button>
        </div>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gradient-to-br from-green-700 to-green-800 p-6 rounded-lg border border-green-600">
          <p className="text-green-200 text-sm font-semibold mb-1">Máquinas em Bom Estado</p>
          <p className="text-4xl font-bold text-white">{bom}</p>
        </div>
        <div className="bg-gradient-to-br from-red-700 to-red-800 p-6 rounded-lg border border-red-600">
          <p className="text-red-200 text-sm font-semibold mb-1">Máquinas Paradas</p>
          <p className="text-4xl font-bold text-white">{parada}</p>
        </div>
      </div>

      {/* Tabela de Máquinas */}
      <div id="checklist-maquinas-content" className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-900 border-b border-slate-700">
            <tr>
              <th className="px-6 py-4 text-left text-white font-semibold">Máquina</th>
              <th className="px-6 py-4 text-left text-white font-semibold">Status</th>
              <th className="px-6 py-4 text-left text-white font-semibold">Observações</th>
              <th className="px-6 py-4 text-left text-white font-semibold">Data</th>
              <th className="px-6 py-4 text-left text-white font-semibold">Responsável</th>
              <th className="px-6 py-4 text-left text-white font-semibold">Ações</th>
            </tr>
          </thead>
          <tbody>
            {maquinas.map((maquina) => (
              <tr key={maquina.id} className="border-b border-slate-700 hover:bg-slate-700/50 transition">
                <td className="px-6 py-4 text-white font-semibold">{maquina.tipo} {maquina.numero}</td>
                <td className="px-6 py-4">
                  {editandoId === maquina.id ? (
                    <select
                      value={editandoDados?.status || 'bom'}
                      onChange={(e) => setEditandoDados(prev => prev ? { ...prev, status: e.target.value as any } : null)}
                      className="bg-slate-600 text-white px-3 py-1 rounded text-sm"
                    >
                      <option value="bom">Bom</option>
                      <option value="parada">Parada</option>
                    </select>
                  ) : (
                    <div className="flex gap-2">
                      <button
                        onClick={() => atualizarStatus(maquina.id, 'bom')}
                        className={`px-3 py-1 rounded text-sm font-semibold text-white transition ${
                          maquina.status === 'bom' ? 'bg-green-600' : 'bg-slate-600 hover:bg-slate-500'
                        }`}
                      >
                        ✓ Bom
                      </button>
                      <button
                        onClick={() => atualizarStatus(maquina.id, 'parada')}
                        className={`px-3 py-1 rounded text-sm font-semibold text-white transition ${
                          maquina.status === 'parada' ? 'bg-red-600' : 'bg-slate-600 hover:bg-slate-500'
                        }`}
                      >
                        ✗ Parada
                      </button>
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 text-gray-300">
                  {editandoId === maquina.id ? (
                    <input
                      type="text"
                      value={editandoDados?.observacoes || ''}
                      onChange={(e) => setEditandoDados(prev => prev ? { ...prev, observacoes: e.target.value } : null)}
                      className="bg-slate-600 text-white px-3 py-1 rounded w-full text-sm"
                      placeholder="Observações..."
                    />
                  ) : (
                    <span>{maquina.observacoes || '-'}</span>
                  )}
                </td>
                <td className="px-6 py-4 text-gray-300 text-sm">{maquina.data}</td>
                <td className="px-6 py-4 text-gray-300">{maquina.responsavel}</td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    {editandoId === maquina.id ? (
                      <>
                        <button
                          onClick={salvarEdicao}
                          className="text-green-400 hover:text-green-300 transition"
                          title="Salvar"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          onClick={cancelarEdicao}
                          className="text-red-400 hover:text-red-300 transition"
                          title="Cancelar"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => iniciarEdicao(maquina)}
                          className="text-blue-400 hover:text-blue-300 transition"
                          title="Editar"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deletarMaquina(maquina.id)}
                          className="text-red-400 hover:text-red-300 transition"
                          title="Deletar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Resumo */}
      <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
        <h3 className="text-xl font-bold text-white mb-4">Resumo do Check-List</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-gray-400 text-sm">Total de Máquinas</p>
            <p className="text-2xl font-bold text-white">{maquinas.length}</p>
          </div>
          <div>
            <p className="text-green-400 text-sm">Em Bom Estado</p>
            <p className="text-2xl font-bold text-green-400">{bom}</p>
          </div>
          <div>
            <p className="text-red-400 text-sm">Paradas</p>
            <p className="text-2xl font-bold text-red-400">{parada}</p>
          </div>
          <div>
            <p className="text-gray-400 text-sm">Taxa de Disponibilidade</p>
            <p className="text-2xl font-bold text-white">{maquinas.length > 0 ? Math.round((bom / maquinas.length) * 100) : 0}%</p>
          </div>
        </div>
      </div>
    </div>
  );
}
