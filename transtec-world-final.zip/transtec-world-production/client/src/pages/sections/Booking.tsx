import React, { useState } from 'react';
import { Truck, Calendar, Plus } from 'lucide-react';

export default function BookingPage() {
  const [bookings, setBookings] = useState([
    { id: 1, codigo: 'BOOK-2025-001', veiculo: 'VW Constellation', data: '2025-04-20', status: 'Confirmado' },
    { id: 2, codigo: 'BOOK-2025-002', veiculo: 'Scania R440', data: '2025-04-21', status: 'Pendente' },
    { id: 3, codigo: 'BOOK-2025-003', veiculo: 'Volvo FH16', data: '2025-04-22', status: 'Confirmado' },
  ]);

  const [formData, setFormData] = useState({
    dataBooking: '',
    veiculo: '',
    motorista: '',
    origem: '',
    destino: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Booking criado:', formData);
    setFormData({
      dataBooking: '',
      veiculo: '',
      motorista: '',
      origem: '',
      destino: '',
    });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Booking de Transporte</h2>
      
      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Data do Booking</label>
              <input 
                type="date" 
                name="dataBooking"
                value={formData.dataBooking}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" 
                required
              />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Veículo</label>
              <select 
                name="veiculo"
                value={formData.veiculo}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              >
                <option value="">Selecionar...</option>
                <option value="VW Constellation">VW Constellation</option>
                <option value="Scania R440">Scania R440</option>
                <option value="Volvo FH16">Volvo FH16</option>
                <option value="Mercedes Actros">Mercedes Actros</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Motorista</label>
            <input 
              type="text" 
              name="motorista"
              value={formData.motorista}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" 
              placeholder="Nome do motorista" 
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Origem</label>
              <input 
                type="text" 
                name="origem"
                value={formData.origem}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" 
                placeholder="Cidade" 
                required
              />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Destino</label>
              <input 
                type="text" 
                name="destino"
                value={formData.destino}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" 
                placeholder="Cidade" 
                required
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Criar Booking
          </button>
        </form>
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Calendar className="w-6 h-6 text-indigo-400" />
          Bookings Agendados
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-gray-300">
            <thead>
              <tr className="border-b border-slate-600">
                <th className="pb-3 font-semibold text-white">Código</th>
                <th className="pb-3 font-semibold text-white">Veículo</th>
                <th className="pb-3 font-semibold text-white">Data</th>
                <th className="pb-3 font-semibold text-white">Status</th>
                <th className="pb-3 font-semibold text-white">Ações</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr key={booking.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                  <td className="py-3 font-semibold text-white">{booking.codigo}</td>
                  <td className="py-3 flex items-center gap-2">
                    <Truck className="w-4 h-4 text-indigo-400" />
                    {booking.veiculo}
                  </td>
                  <td className="py-3">{booking.data}</td>
                  <td className="py-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      booking.status === 'Confirmado' ? 'bg-green-600 text-white' : 'bg-amber-600 text-white'
                    }`}>
                      {booking.status}
                    </span>
                  </td>
                  <td className="py-3">
                    <button className="text-indigo-400 hover:text-indigo-300 font-semibold mr-3">Editar</button>
                    <button className="text-red-400 hover:text-red-300 font-semibold">Cancelar</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
