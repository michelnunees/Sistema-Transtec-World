import React, { useState } from 'react';
import { Inbox, Plus, Download } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';

const CATEGORIAS = [
  'Químicos',
  'Tintas e Vedação',
  'Tintas',
  'Elétrica',
  'Fixação',
  'Hidráulica',
  'Diversos',
  'Solda e Corte',
  'Corte e Acabamento',
  'Manuais',
  'Chaves',
  'Elétricas / Pneumáticas',
  'Aplicação',
  'Mangueiras',
];

export default function EntradasPage() {
  const { generatePDF } = usePDFGenerator();
  const [entradas, setEntradas] = useState([
    { id: 1, nome: 'Parafuso M8', data: '2025-04-16', categoria: 'Fixação', status: 'Processando' },
    { id: 2, nome: 'Tinta Vermelha', data: '2025-04-16', categoria: 'Tintas', status: 'Processando' },
    { id: 3, nome: 'Chave Inglesa', data: '2025-04-15', categoria: 'Chaves', status: 'Concluído' },
  ]);

  const [formData, setFormData] = useState({
    nome: '',
    dataEntrada: '',
    categoria: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.nome && formData.dataEntrada && formData.categoria) {
      setEntradas(prev => [...prev, {
        id: Math.max(...prev.map(e => e.id), 0) + 1,
        nome: formData.nome,
        data: formData.dataEntrada,
        categoria: formData.categoria,
        status: 'Processando',
      }]);
      setFormData({
        nome: '',
        dataEntrada: '',
        categoria: '',
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Registrar Entradas</h2>
        <button
          onClick={() => generatePDF('entradas-content', 'entradas', 'Relatório de Entradas - TRANSTEC WORLD')}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Gerar PDF
        </button>
      </div>

      <div id="entradas-content" className="space-y-6">

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <form onSubmit={handleSubmit} className="space-y-4">
          <h3 className="text-lg font-bold text-white mb-4">Nova Entrada</h3>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Nome do Produto</label>
            <input
              type="text"
              name="nome"
              value={formData.nome}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              placeholder="Ex: Parafuso M8"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Data de Entrada</label>
              <input
                type="date"
                name="dataEntrada"
                value={formData.dataEntrada}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                required
              />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Tipo de Carga / Setor</label>
              <select
                name="categoria"
                value={formData.categoria}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                required
              >
                <option value="">Selecionar...</option>
                {CATEGORIAS.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Registrar Entrada
          </button>
        </form>
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Inbox className="w-6 h-6 text-green-400" />
          Entradas Recentes
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-gray-300">
            <thead>
              <tr className="border-b border-slate-600">
                <th className="pb-3 font-semibold text-white">Produto</th>
                <th className="pb-3 font-semibold text-white">Data</th>
                <th className="pb-3 font-semibold text-white">Categoria</th>
                <th className="pb-3 font-semibold text-white">Status</th>
                <th className="pb-3 font-semibold text-white">Ações</th>
              </tr>
            </thead>
            <tbody>
              {entradas.map((entrada) => (
                <tr key={entrada.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                  <td className="py-3 font-semibold text-white">{entrada.nome}</td>
                  <td className="py-3">{entrada.data}</td>
                  <td className="py-3">{entrada.categoria}</td>
                  <td className="py-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold text-white ${
                      entrada.status === 'Concluído' ? 'bg-green-600' : 'bg-blue-600'
                    }`}>
                      {entrada.status}
                    </span>
                  </td>
                  <td className="py-3">
                    <button className="text-green-400 hover:text-green-300 font-semibold text-sm mr-3">Editar</button>
                    <button className="text-red-400 hover:text-red-300 font-semibold text-sm">Deletar</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      </div>
    </div>
  );
}
