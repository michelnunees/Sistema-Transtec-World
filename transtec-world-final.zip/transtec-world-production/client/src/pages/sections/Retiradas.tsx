import React, { useState } from 'react';
import { Wrench, Plus, Download } from 'lucide-react';
import { usePDFGenerator } from '@/hooks/usePDFGenerator';

export default function RetiradasPage() {
  const { generatePDF } = usePDFGenerator();
  const [retiradas, setRetiradas] = useState([
    { id: 1, ferramenta: 'Chave Inglesa 10"', data: '2025-04-16', setor: 'Manutenção', quantidade: 1, responsavel: 'João Silva', observacao: 'Reparo na máquina' },
    { id: 2, ferramenta: 'Furadeira Elétrica', data: '2025-04-16', setor: 'Oficina', quantidade: 1, responsavel: 'Maria Santos', observacao: 'Manutenção preventiva' },
    { id: 3, ferramenta: 'Jogo de Chaves', data: '2025-04-15', setor: 'Elétrica', quantidade: 1, responsavel: 'Pedro Costa', observacao: '' },
  ]);

  const [formData, setFormData] = useState({
    ferramenta: '',
    data: '',
    setor: '',
    quantidade: '',
    responsavel: '',
    observacao: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Retirada registrada:', formData);
    setFormData({
      ferramenta: '',
      data: '',
      setor: '',
      quantidade: '',
      responsavel: '',
      observacao: '',
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Retiradas de Ferramentas</h2>
        <button
          onClick={() => generatePDF('retiradas-content', 'retiradas', 'Relatório de Retiradas - TRANSTEC WORLD')}
          className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg font-semibold transition flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Gerar PDF
        </button>
      </div>

      <div id="retiradas-content" className="space-y-6">

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <form onSubmit={handleSubmit} className="space-y-4">
          <h3 className="text-lg font-bold text-white mb-4">Registrar Retirada de Ferramenta</h3>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Ferramenta</label>
              <input
                type="text"
                name="ferramenta"
                value={formData.ferramenta}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="Ex: Chave Inglesa"
                required
              />
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Data</label>
              <input
                type="date"
                name="data"
                value={formData.data}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Setor</label>
              <select
                name="setor"
                value={formData.setor}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                required
              >
                <option value="">Selecionar...</option>
                <option value="Manutenção">Manutenção</option>
                <option value="Oficina">Oficina</option>
                <option value="Elétrica">Elétrica</option>
                <option value="Hidráulica">Hidráulica</option>
                <option value="Solda">Solda</option>
                <option value="Corte">Corte</option>
                <option value="Acabamento">Acabamento</option>
              </select>
            </div>
            <div>
              <label className="block text-gray-300 font-semibold mb-2">Quantidade</label>
              <input
                type="number"
                name="quantidade"
                value={formData.quantidade}
                onChange={handleInputChange}
                className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="1"
                min="1"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Responsável</label>
            <input
              type="text"
              name="responsavel"
              value={formData.responsavel}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              placeholder="Nome do responsável"
              required
            />
          </div>

          <div>
            <label className="block text-gray-300 font-semibold mb-2">Observação</label>
            <textarea
              name="observacao"
              value={formData.observacao}
              onChange={handleInputChange}
              className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              placeholder="Motivo ou observação da retirada..."
              rows={3}
            />
          </div>

          <button
            type="submit"
            className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Registrar Retirada
          </button>
        </form>
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Wrench className="w-6 h-6 text-amber-400" />
          Retiradas Recentes
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-gray-300">
            <thead>
              <tr className="border-b border-slate-600">
                <th className="pb-3 font-semibold text-white">Ferramenta</th>
                <th className="pb-3 font-semibold text-white">Data</th>
                <th className="pb-3 font-semibold text-white">Setor</th>
                <th className="pb-3 font-semibold text-white">Responsável</th>
                <th className="pb-3 font-semibold text-white">Observação</th>
              </tr>
            </thead>
            <tbody>
              {retiradas.map((ret) => (
                <tr key={ret.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                  <td className="py-3 font-semibold text-white">{ret.ferramenta}</td>
                  <td className="py-3">{ret.data}</td>
                  <td className="py-3">{ret.setor}</td>
                  <td className="py-3">{ret.responsavel}</td>
                  <td className="py-3 text-sm">{ret.observacao || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      </div>
    </div>
  );
}
