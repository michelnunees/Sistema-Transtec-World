import React, { useState } from 'react';
import { Package, Plus, Search } from 'lucide-react';

export default function LogisticasPage() {
  const [operacoes, setOperacoes] = useState([
    { id: 1, codigo: 'LOG-2025-001', tipo: 'Container', status: 'Em Trânsito', data: '2025-04-16' },
    { id: 2, codigo: 'LOG-2025-002', tipo: 'Pallet', status: 'Entregue', data: '2025-04-15' },
    { id: 3, codigo: 'LOG-2025-003', tipo: 'Carga Geral', status: 'Aguardando', data: '2025-04-14' },
  ]);

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Gestão de Logística</h2>
      
      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <p className="text-gray-300 mb-6">Operações logísticas do terminal e armazenagem.</p>
        
        <div className="space-y-4">
          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2">
            <Plus className="w-5 h-5" />
            Nova Operação Logística
          </button>
          
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <input 
              type="text" 
              placeholder="Buscar operações..." 
              className="w-full bg-slate-600 text-white pl-10 pr-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600">
        <h3 className="text-xl font-bold text-white mb-4">Operações Recentes</h3>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-gray-300">
            <thead>
              <tr className="border-b border-slate-600">
                <th className="pb-3 font-semibold text-white">Código</th>
                <th className="pb-3 font-semibold text-white">Tipo</th>
                <th className="pb-3 font-semibold text-white">Status</th>
                <th className="pb-3 font-semibold text-white">Data</th>
                <th className="pb-3 font-semibold text-white">Ações</th>
              </tr>
            </thead>
            <tbody>
              {operacoes.map((op) => (
                <tr key={op.id} className="border-b border-slate-600 hover:bg-slate-600 transition">
                  <td className="py-3">{op.codigo}</td>
                  <td className="py-3 flex items-center gap-2">
                    <Package className="w-4 h-4 text-blue-400" />
                    {op.tipo}
                  </td>
                  <td className="py-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      op.status === 'Em Trânsito' ? 'bg-blue-600 text-white' :
                      op.status === 'Entregue' ? 'bg-green-600 text-white' :
                      'bg-amber-600 text-white'
                    }`}>
                      {op.status}
                    </span>
                  </td>
                  <td className="py-3">{op.data}</td>
                  <td className="py-3">
                    <button className="text-blue-400 hover:text-blue-300 font-semibold">Ver</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
