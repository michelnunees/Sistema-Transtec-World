import React, { useState } from 'react';
import { LayoutDashboard, CheckSquare, Inbox, LogOut, Wrench, Package, Search, Lock, MapPin, Warehouse, Home as HomeIcon, LogIn } from 'lucide-react';
import PainelGeralPage from './sections/PainelGeral';
import CheckListPage from './sections/CheckList';
import CheckListMaquinasPage from './sections/CheckListMaquinas';
import EntradasPage from './sections/Entradas';
import SaidasPage from './sections/Saidas';
import RetiradasPage from './sections/Retiradas';
import InventarioPage from './sections/Inventario';
import LocalizarEstimativaPage from './sections/LocalizarEstimativa';
import AlmoxarifadoPage from './sections/Almoxarifado';

/**
 * TRANSTEC WORLD - Sistema de Controle Integrado
 * Design: Industrial Minimalism com foco em eficiência operacional
 * Paleta: Azul profundo, gradientes slate, acentos funcionais por módulo
 */

export default function Home() {
  const [menuAtivo, setMenuAtivo] = useState('home');
  const [usuarioLogado, setUsuarioLogado] = useState(false);
  const [loginData, setLoginData] = useState({
    matricula: '',
    senha: '',
    terminal: 'Terminal Continental',
  });

  const menuPrincipal = [
    { id: 'painel-geral', label: 'Painel Geral', icon: LayoutDashboard, cor: 'from-blue-600 to-blue-700' },
    { id: 'check-list', label: 'Check-List de Tarefas', icon: CheckSquare, cor: 'from-purple-600 to-purple-700' },
    { id: 'check-list-maquinas', label: 'Check-List Diário de Máquinas', icon: Package, cor: 'from-pink-600 to-pink-700' },
    { id: 'entradas', label: 'Entradas', icon: Inbox, cor: 'from-green-600 to-green-700' },
    { id: 'saidas', label: 'Saídas', icon: LogOut, cor: 'from-red-600 to-red-700' },
    { id: 'retiradas', label: 'Retiradas de Ferramentas', icon: Wrench, cor: 'from-amber-600 to-amber-700' },
    { id: 'inventario', label: 'Inventário', icon: Package, cor: 'from-cyan-600 to-cyan-700' },
    { id: 'localizar-estimativa', label: 'Localizar Estimativa', icon: Search, cor: 'from-indigo-600 to-indigo-700' },
  ];

  const submenu = [
    { id: 'almoxarifado', label: 'Almoxarifado', icon: Warehouse },
  ];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginData.matricula && loginData.senha) {
      setUsuarioLogado(true);
      setMenuAtivo('painel-geral');
    }
  };

  const handleLogout = () => {
    setUsuarioLogado(false);
    setLoginData({ matricula: '', senha: '', terminal: 'Terminal Continental' });
    setMenuAtivo('home');
  };

  const renderizarConteudo = () => {
    switch(menuAtivo) {
      case 'home':
        return (
          <div className="space-y-8">
            <div className="text-center py-12">
              <h1 className="text-5xl font-bold text-white mb-4">
                Sistema de Controle Integrado
              </h1>
              <p className="text-gray-300 text-lg">
                TRANSTEC WORLD - Terminal Continental
              </p>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600 hover:border-slate-500 transition">
                <LayoutDashboard className="w-12 h-12 text-blue-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Painel Geral</h3>
                <p className="text-gray-300">Visão geral de todas as operações</p>
              </div>
              <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600 hover:border-slate-500 transition">
                <CheckSquare className="w-12 h-12 text-purple-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Check-List</h3>
                <p className="text-gray-300">Controle e documentação diária</p>
              </div>
              <div className="bg-gradient-to-br from-slate-700 to-slate-800 p-8 rounded-xl border border-slate-600 hover:border-slate-500 transition">
                <Package className="w-12 h-12 text-cyan-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Inventário</h3>
                <p className="text-gray-300">Gestão de estoque e produtos</p>
              </div>
            </div>
          </div>
        );
      
      case 'painel-geral':
        return <PainelGeralPage />;
      case 'check-list':
        return <CheckListPage />;
      case 'check-list-maquinas':
        return <CheckListMaquinasPage />;
      case 'entradas':
        return <EntradasPage />;
      case 'saidas':
        return <SaidasPage />;
      case 'retiradas':
        return <RetiradasPage />;
      case 'inventario':
        return <InventarioPage />;
      case 'localizar-estimativa':
        return <LocalizarEstimativaPage />;
      case 'almoxarifado':
        return <AlmoxarifadoPage />;

      default:
        return (
          <div className="text-center py-12">
            <p className="text-gray-300 text-lg">Selecione uma opção no menu</p>
          </div>
        );
    }
  };

  if (!usuarioLogado) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-8 border border-slate-700">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-white mb-2">TRANSTEC WORLD</h1>
              <p className="text-gray-400">Terminal Continental</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-gray-300 font-semibold mb-2">Matrícula</label>
                <input
                  type="text"
                  value={loginData.matricula}
                  onChange={(e) => setLoginData({ ...loginData, matricula: e.target.value })}
                  className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Digite sua matrícula"
                  required
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-2">Senha</label>
                <input
                  type="password"
                  value={loginData.senha}
                  onChange={(e) => setLoginData({ ...loginData, senha: e.target.value })}
                  className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Digite sua senha"
                  required
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-2">Terminal</label>
                <select
                  value={loginData.terminal}
                  onChange={(e) => setLoginData({ ...loginData, terminal: e.target.value })}
                  className="w-full bg-slate-600 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option>Terminal Continental</option>
                  <option>Terminal Centro</option>
                  <option>Terminal Zona Leste</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2 mt-6"
              >
                <LogIn className="w-5 h-5" />
                Entrar
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-950 to-slate-900 border-b border-slate-700 p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">TRANSTEC WORLD</h1>
            <p className="text-gray-400 text-sm">Terminal & Logística Ltda.</p>
          </div>
          <div className="text-right">
            <p className="text-gray-300 text-sm">{loginData.terminal}</p>
            <p className="text-gray-400 text-xs">{new Date().toLocaleDateString('pt-BR')}</p>
            <button
              onClick={handleLogout}
              className="mt-2 text-red-400 hover:text-red-300 font-semibold text-sm flex items-center gap-1 ml-auto"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-6 gap-6">
          {/* Menu Principal */}
          <div className="col-span-2">
            <div className="space-y-4">
              <button
                onClick={() => setMenuAtivo('home')}
                className={`w-full p-4 rounded-lg font-semibold flex items-center gap-3 transition ${
                  menuAtivo === 'home'
                    ? 'bg-slate-700 text-white border-2 border-slate-500'
                    : 'bg-slate-700 hover:bg-slate-600 text-gray-300'
                }`}
              >
                <HomeIcon className="w-5 h-5" />
                Início
              </button>

              {menuPrincipal.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setMenuAtivo(item.id)}
                  className={`w-full p-4 rounded-lg font-semibold flex items-center gap-3 transition ${
                    menuAtivo === item.id
                      ? `bg-gradient-to-r ${item.cor} text-white shadow-lg`
                      : 'bg-slate-700 hover:bg-slate-600 text-gray-300'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              ))}
            </div>

            {/* Submenu */}
            <div className="mt-8 p-4 bg-slate-700 rounded-lg border border-slate-600">
              <p className="text-gray-400 text-xs font-semibold uppercase mb-3">Operações</p>
              <div className="space-y-2">
                {submenu.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setMenuAtivo(item.id)}
                    className={`w-full text-left p-3 rounded hover:bg-slate-600 text-gray-300 hover:text-white transition flex items-center gap-2 text-sm ${
                      menuAtivo === item.id ? 'bg-slate-600 text-white' : ''
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Conteúdo Principal */}
          <div className="col-span-4">
            <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-8 border border-slate-700 min-h-screen">
              {renderizarConteudo()}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-700 p-4 text-center text-gray-500 text-sm mt-12">
        <p>© 2025 TRANSTEC WORLD - Todos os direitos reservados</p>
      </footer>
    </div>
  );
}
