import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas-pro';

export const usePDFGenerator = () => {
  const generatePDF = async (elementId: string, fileName: string, title: string) => {
    try {
      const element = document.getElementById(elementId);
      if (!element) {
        console.error(`Element with id ${elementId} not found`);
        return;
      }

      // Captura o elemento diretamente com html2canvas-pro (suporta oklch do Tailwind v4)
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#1a202c',
        allowTaint: true,
        foreignObjectRendering: false,
        ignoreElements: (el) => {
          return el.tagName === 'SCRIPT';
        },
      }).catch(err => {
        console.error('Canvas rendering error:', err);
        return null;
      });

      if (!canvas) {
        throw new Error('Falha ao renderizar canvas');
      }

      // Dimensões A4 em mm
      const PDF_WIDTH = 210;
      const PDF_MARGIN = 10;
      const CONTENT_WIDTH = PDF_WIDTH - PDF_MARGIN * 2;
      const HEADER_HEIGHT = 32;

      // Calcula a altura proporcional da imagem
      const imgWidth = CONTENT_WIDTH;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      // Cria o PDF
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageHeight = pdf.internal.pageSize.getHeight();
      const availableHeight = pageHeight - HEADER_HEIGHT - PDF_MARGIN;
      const totalPages = Math.max(1, Math.ceil(imgHeight / availableHeight));
      const imgData = canvas.toDataURL('image/png');

      // Função para adicionar cabeçalho em cada página
      const addHeader = (pageNum: number) => {
        pdf.setFillColor(26, 32, 44);
        pdf.rect(0, 0, PDF_WIDTH, HEADER_HEIGHT, 'F');
        pdf.setFontSize(13);
        pdf.setTextColor(255, 255, 255);
        pdf.text(title, PDF_MARGIN, 11);
        pdf.setFontSize(8);
        pdf.setTextColor(180, 180, 180);
        pdf.text(`Data: ${new Date().toLocaleDateString('pt-BR')}`, PDF_MARGIN, 19);
        pdf.text(`Hora: ${new Date().toLocaleTimeString('pt-BR')}`, PDF_MARGIN + 45, 19);
        pdf.text(`Pág. ${pageNum}/${totalPages}`, PDF_WIDTH - PDF_MARGIN - 20, 19);
        pdf.setDrawColor(80, 80, 80);
        pdf.line(PDF_MARGIN, HEADER_HEIGHT - 2, PDF_WIDTH - PDF_MARGIN, HEADER_HEIGHT - 2);
      };

      // Adiciona cada página com a fatia correta da imagem
      for (let page = 0; page < totalPages; page++) {
        if (page > 0) pdf.addPage();

        // Posição Y da imagem para mostrar a fatia correta
        const yOffset = HEADER_HEIGHT - page * availableHeight;
        pdf.addImage(imgData, 'PNG', PDF_MARGIN, yOffset, imgWidth, imgHeight);

        // Máscara superior (cobre a área do cabeçalho)
        pdf.setFillColor(26, 32, 44);
        pdf.rect(0, 0, PDF_WIDTH, HEADER_HEIGHT, 'F');
        addHeader(page + 1);

        // Máscara inferior (cobre o que ultrapassa a área de conteúdo)
        const contentBottom = HEADER_HEIGHT + availableHeight;
        if (contentBottom < pageHeight) {
          pdf.setFillColor(26, 32, 44);
          pdf.rect(0, contentBottom, PDF_WIDTH, pageHeight - contentBottom + 1, 'F');
        }
      }

      // Salva o PDF
      pdf.save(`${fileName}_${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      alert(`Erro ao gerar PDF: ${error instanceof Error ? error.message : 'Tente novamente.'}`);
    }
  };

  return { generatePDF };
};
